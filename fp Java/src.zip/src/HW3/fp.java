package HW3;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.function.Function;
import java.util.function.BiFunction;
import java.util.function.Predicate;
import java.util.Comparator;



public class fp {
	
static <U,V> List<V> map(Iterable<U> l, Function<U,V> f) {
	List<V> list = new ArrayList<V>();
	for (U u : l)
	{
		list.add(f.apply(u));
		
	}
	return list;
}


static <U,V> V foldLeft(V e, Iterable<U>l, BiFunction<V,U,V> f){
	V answer  = e;

	for (U u : l)
	{
		answer = f.apply(answer ,u);
		
	}
	return answer;

}




static <U,V> V foldRight(V e, java.util.List<U>l, BiFunction<U,V,V> f){

	V answer = e;
	
	for( U u : l)
	{
		answer = f.apply(u, answer);
	}
	return answer;
}



static <U> Iterable<U> filter(Iterable<U> l, Predicate<U> p){
	List<U> list = new ArrayList<U>();
	
	for (U u : l)
	{
		if (p.test(u))
			list.add(u);
	}
	
	
return list;
}

static <U> U minVal(Iterable<U> l, Comparator<U> c){
	// write using fold.  No other loops or recursion permitted. 
	BiFunction<U, U, U> biFunction = (a,b)-> 
	{
		if( c.compare( a, b) < 0)
		{
			return a;
		}else {
			return b;
		}
	};
	
	return foldLeft(l.iterator().next(), l, biFunction);

}
static <U extends Comparable<U>> int minPos(Iterable<U> l){
	// write using fold.  No other loops or recursion permitted. 
	List<U> list = (List<U>) l;
	BiFunction<Integer, U, Integer> biFunction = (a, b)-> 
	{
		if(list.get(a).compareTo(b)< 0)
		{
			return a;
		}else {
			return list.indexOf(b);
			
		}
	};
	
	Integer mini = 0;
	return foldLeft(mini, l, biFunction);
	
	


}

	public static void main(String[] args) {
		// (1) Use map to implement the following behavior (described in Python).  i.e given a List<T> create a List<Integer> of the hashes of the objects.
		// names = ['Mary', 'Isla', 'Sam']
		// for i in range(len(names)):
		       // names[i] = hash(names[i])
		
		Iterable<String> PName = Arrays.asList("Mary", "Isla", "Sam");
		Function<String, Integer> ftion = x -> x.hashCode();
		List<Integer> list = map(PName, ftion);
		list.stream().forEach(x -> System.out.println(x));
		
		// (2) Use foldleft to calculate the sum of a list of integers.
		// i.e write a method: int sum(List<Integer> l)
		
		List<Integer> ints = Arrays.asList(1, 2, 3);
		BiFunction<Integer, Integer, Integer> biFunction = (a, b) -> a + b;
		Integer result = foldLeft(0, ints, biFunction);
		assert result == 6;
		
		// (3) Use foldRight to concatenate a list of strings i.e write a method
		// String s (List<String> l)
		
		List<String> strings = Arrays.asList("a", "b", "c");
		BiFunction<String, String, String> ConcatenatebiFunction = (s1, s2) -> s1 + s2;
		String stringResult = foldRight("", strings, ConcatenatebiFunction);
		assert "cba".equals(stringResult);
		
		// (4) consider an array of Persons. Use filter to 
		// print the names of the Persons whose salary is
		// greater than 100000
		
		Person p1 = new Person(80000, "Mary");
		Person p2 = new Person(120000, "Isla");
		Person p3 = new Person(220000, "Sam");
		
		List<Person> PList = new ArrayList<>(Arrays.asList(p1,p2,p3));
		Predicate<Person> predicate = person -> person.salary > 100000;
		Iterable<Person> PersonL = filter(PList, predicate);
		PersonL.forEach(p -> System.out.println(p.name));
			
		
		// (5) Use minVal to calculate the minimum of a List of 
		//       Integers
		List<Integer> MinV = Arrays.asList(44,7,14,99,5);
		Integer miniIntVal = minVal(MinV, (x,y) -> {
			return ( x < y) ? -1 : ((x == y) ? 0 : 1);
			
		});
		assert miniIntVal == 1;
		System.out.println("The Min Value is: " + miniIntVal);
		
		
        // (6) Use minVal to calculate the maximum of a List of 
		//       Integers
		List<Integer> MaxV = Arrays.asList(44,7,14,99,5);
		Integer maxVal = minVal(MaxV, (x,y) -> {
			return (x < y) ? 1 :(( x == y) ? 0 : -1);
		});
		assert maxVal == 99;
		System.out.println("The MaxVal is: "+ maxVal);
		
		
		// (7)  Use minPos to calculate the position of the
		// minimum in  a List of  Integers
		
		int IntsminPosition = minPos(Arrays.asList(44, 7, 14, 99, 5));
		assert IntsminPosition == 4;
		System.out.println("The Min Poositon of the Integer list is: " + IntsminPosition);

		// (8)  Use minPos to calculate the position of the
		// minimum in  a List of  String
		
		int StringMinPos = minPos(Arrays.asList("abc", "abcd", "", "a"));
		assert StringMinPos == 3;
		System.out.println("The Min Position of the String list is: " + StringMinPos);
	}

}

class Person{
	final int salary;
	final String name;
	
	Person(int salary, String name){
		this.salary = salary;
		this.name = name;
	}
	
	int getSalary() { return salary; }
	String name() { return name;}
	
}

