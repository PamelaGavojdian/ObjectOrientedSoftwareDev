package HW3;

import static org.junit.jupiter.api.Assertions.*;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import org.junit.Assert;
import org.junit.jupiter.api.Test;



class fpTest {

	@Test
	void testMap() {
		Iterable<String> PName = Arrays.asList("Mary", "Isla", "Sam");
		Function<String, Integer> ftion = x -> x.hashCode();
        List<Integer> list = fp.map(PName, ftion);
        list.stream().forEach(x -> System.out.println(x));
        Assert.assertEquals(3, list.size());
		
        //LinkedList<Integer> l = new LinkedList<>();
		//for (int i=0; i < 10; i++) l.addFirst(i+1);
		//List<Integer> u = fp.map(l, (Integer x) -> {return x+1;});
	}
	@Test
	void TestFoldLeft() {
		List<Integer> ints = Arrays.asList(1,2,3);
		BiFunction<Integer, Integer, Integer> biFunction = (a,b) -> a + b;
		int answer = fp.foldLeft(0, ints, biFunction);
		Assert.assertEquals(6, answer);
		
	}
	@Test
	void TestFoldRight() {
		List<String> Lstrings = Arrays.asList("a", "b", "c");
		BiFunction<String,String, String> ConcatenatebiFunction = (s1, s2) ->
			s1 + s2;
		String stringResult = fp.foldRight("", Lstrings,ConcatenatebiFunction);
		Assert.assertEquals("cba", stringResult);
		
		LinkedList<Integer> l = new LinkedList<>();
		for (int i=0; i < 10; i++) l.addFirst(i+1);
		assertTrue(55 == fp.foldRight(0, l, (Integer x, Integer y) -> {return x+y;}));
	}

	
	
	@Test
	void TestPerson() {
		Person p1 = new Person(80000, "Mary");
		Person p2 = new Person(120000, "Isla");
		Person p3 = new Person(220000, "Sam");
		List<Person> PList =  new ArrayList<>(Arrays.asList(p1,p2,p3));
		Predicate<Person> predicate = person -> person.salary > 100000;
		List<Person> PersonL = (List<Person>) fp.filter(PList, predicate);
		Assert.assertEquals(2, PersonL.size()); // LIST OF PEOPLE OVER 100000
		Assert.assertEquals(false,  PersonL.contains(p1));
		Assert.assertEquals(true,  PersonL.contains(p2));
		Assert.assertEquals(true,  PersonL.contains(p3));
		PersonL.forEach(p -> System.out.println(p.name)); // PRINT OUT NAMES FROM THAT LIST
		
		
	}
	
	
	
	@Test
	void testMaxV() {
		List<Integer> MaxV = Arrays.asList(44,7,14,99,5);
		Integer maxVal = fp.minVal(MaxV, (x,y) ->{
			return ( x < y) ? 1 : ((x == y) ? 0 : -1);
		});
		
		assert maxVal == 99;
		
		System.out.println("The Max Value is: "+ maxVal);
		Assert.assertEquals(99,maxVal.intValue());
		
		
	}

	@Test
	void testMinVal() {
		List<Integer> MinV =
				Arrays.asList(44,7,14,99,5); // the list to find the minVal in
		Integer miniIntVal = fp.minVal(MinV, (x,y) ->
		{
			return( x < y)? -1 : ((x == y) ? 0 : 1);
			
		});
		System.out.println("The Min Value is : "+ miniIntVal); // return the Min
		
		Assert.assertEquals(5, miniIntVal.intValue()); // MinValue should be 5
		
		
		
		//LinkedList<Integer> l = new LinkedList<>();
		//for (int i=0; i < 10; i++) l.addFirst(i+1);
		
		//assertTrue(1==fp.minVal(l, (Integer x, Integer y) -> {return x-y;} ));
	}


	@Test
	void testIntsminPosition() {
		LinkedList<Integer> l = new LinkedList<>();
		for (int i=0; i < 10; i++) l.addFirst(i+1);
		int IntsminPosition = fp.minPos(Arrays.asList(44,7,14,99,5));
		
		System.out.println("The Min Postition of the Integer list is: "+ IntsminPosition);
		Assert.assertEquals(4, IntsminPosition);
	}
	
	
	
	
	@Test
	void testFilter() {
		LinkedList<Integer> l = new LinkedList<>();
		for (int i=0; i < 10; i++) l.addFirst(i+1);
		
		Iterable<Integer>i = fp.filter(l, (Integer x ) -> {return x%2 == 0;}); 
		int u = 0;
		for (Integer a: i) u++;
		assertTrue(u==5);
	}

	@Test
	void TestStringMinPos()
	{
		int StringMinPos = fp.minPos(Arrays.asList("abc", "abcd", "ab", "a", "abcdef" ));
		
		System.out.println("The minimum Position of the String list is: " + StringMinPos);
		Assert.assertEquals(3, StringMinPos);
	}
	


}
